var d;(d=document.getElementById("open-sidebar"))==null||d.addEventListener("click",()=>{chrome.windows.getCurrent({populate:!0},e=>{e.id!==void 0&&chrome.sidePanel.open({windowId:e.id})})});
